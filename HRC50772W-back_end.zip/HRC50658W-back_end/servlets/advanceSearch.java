package hrc.com;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * Servlet implementation class SearchSalesOrder
 */
@WebServlet("/advanceSearch")
public class advanceSearch extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public advanceSearch() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String invoice=null;
		
		int NO_OF_ROWS_TO_GET = 12;
		
		try {
			Connection conn = dbconnection.dbconnector();
			
			
			BufferedReader reader = request.getReader();
			invoice = reader.readLine();
			System.out.println(invoice);
//			int key = Integer.parseInt(searchKeyword);
			invoice =  invoice.substring(1, invoice.length() - 1);
			String final_values[] = invoice.split(",");
			
			for(int i = 0; i < final_values.length; ++i) {
				final_values[i] = final_values[i].split(":")[1];
				final_values[i] = final_values[i].substring(1, final_values[i].length() - 1);
				System.out.println(final_values[i]);
			}
			String docId=final_values[0];
			String customerNumber = final_values[1];
			String invoiceNumber = final_values[2];
			String businessyear=final_values[3];
			
//			String sql_statement = "SELECT * FROM invoice_details ORDER BY doc_id LIMIT " + page + ", 10";
			String sql_statement = "SELECT * FROM mytable WHERE doc_id LIKE '" + docId + "%' OR cust_number LIKE '"+customerNumber+"%' OR buisness_year LIKE '"+businessyear+"%' OR invoice_id LIKE '"+invoiceNumber+"%'";
			PreparedStatement st = conn.prepareStatement(sql_statement);
			ResultSet rs = st.executeQuery(sql_statement);
//		
			
			ArrayList<InvoiceModel> data = new ArrayList<>();
			while(rs.next()) {
				InvoiceModel inv = new InvoiceModel();
				inv.setSl_no(rs.getString("Sl_no"));
				inv.setClear_date(rs.getString("clear_date"));
				inv.setPosting_date(rs.getString("posting_date"));
				
//				inv.setBusiness_code(rs.getString("business_code"));
				inv.setCust_number(rs.getString("cust_number"));
				
//				inv.setClearDate(rs.getString("clear_date"));
//				inv.setBusinessYear(rs.getInt("business_year"));
				inv.setDoc_id(rs.getLong("doc_id"));
//				inv.setPostingDate(rs.getString("posting_date"));
				inv.setDocument_create_date(rs.getString("document_create_date"));
				inv.setBusiness_year(rs.getString("buisness_year"));
				inv.setDue_in_date(rs.getString("due_in_date"));
				inv.setInvoice_currency(rs.getString("invoice_currency"));
//				inv.seticeCurrency(rs.getString("invoice_currency"));
				inv.setDocument_type(rs.getString("document_type"));
				inv.setPosting_id(rs.getInt("posting_id"));
				inv.setTotal_open_amount(rs.getDouble("total_open_amount"));
				inv.setBusiness_code(rs.getString("business_code"));
				inv.setBaseline_create_date(rs.getString("baseline_create_date"));
				inv.setCust_payment_terms(rs.getString("cust_payment_terms"));
				
				
				inv.setInvoice_id(rs.getLong("Invoice_id"));
				inv.setIsOpen(rs.getInt("isOpen"));
				
				
//				System.out.println(inv);
				
				data.add(inv);
			}
			
			/*
			 * Gson gson = new GsonBuilder().serializeNulls().create(); String invoices =
			 * gson.toJson(data);
			 */
			Gson gson = new Gson();
			String invoices = gson.toJson(data);
			PrintWriter out = response.getWriter();
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			
//			System.out.println(invoices);
			out.print(invoices);
			response.setStatus(200);
			System.out.println(st);
			out.flush();
			rs.close();
			st.close();
		}
	
		catch(SQLException e) {
			e.printStackTrace();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
