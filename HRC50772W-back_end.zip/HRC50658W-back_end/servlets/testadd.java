package hrc.com;

import java.io.BufferedReader;

import java.sql.SQLException;
	
	import java.io.IOException;
	import java.sql.Connection;
	import java.sql.PreparedStatement;
	
import java.sql.Types;
import java.util.HashMap;

import javax.servlet.ServletException;
	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

	/**
	 * Servlet implementation class AddInvoice
	 */
	@WebServlet("/testadd")
	public class testadd extends HttpServlet {
		private static final long serialVersionUID = 1L;

		//private static Connection conn = null;
		//private static PreparedStatement stmt = null;
	    
	    /**
	     * @see HttpServlet#HttpServlet()
	     */
	    public testadd() {
	        super();
	        // TODO Auto-generated constructor stub
	    }
	    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    	response.getWriter().append("Served at: ").append(request.getContextPath());
	    	//request.getRequestDispatcher("/WEB-INF/views/test.jsp").forward(request, response);
	    	response.addHeader("Access-Control-Allow-Origin","http://localhost:3000");   }
		/**
		 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
		 */
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			String invoice = null;
			
			try {
				BufferedReader reader = request.getReader();
				invoice = reader.readLine();
				System.out.println(invoice);
//				System.out.println(invoice.getClass().getName());
				
//				System.out.println(invoice.split(","));
//				System.out.println(invoice.split("\"\""));
//				System.out.println(invoice.split(","));
				
				invoice =  invoice.substring(1, invoice.length() - 1);
				String final_values[] = invoice.split(",");
				
				for(int i = 0; i < final_values.length; ++i) {
					final_values[i] = final_values[i].split(":")[1];
					final_values[i] = final_values[i].substring(1, final_values[i].length() - 1);
					System.out.println(final_values[i]);
				}
				String BusinessCode=final_values[0];
				String docId=final_values[1];
				String invoiceCurrency=final_values[2];
				String baseLinecreatedate=final_values[3];
				String customerNumber = final_values[4];
				String postingDate=final_values[5];
				String doctype=final_values[6];
				String custPayTerms=final_values[7];
				String clearDate=final_values[8];
				//String doccreatedate=final_values[9];
				//String postingId=final_values[9];
				String invoiceNumber = final_values[9];
				String businessyear=final_values[10];
				String duedate=final_values[11];
				String totalopenamt = final_values[12];
				//String dueDate = final_values[4];
			
				
				Connection conn = dbconnection.dbconnector();
				String sql_statement = "INSERT INTO mytable (business_code ,doc_id,invoice_currency,baseline_create_date,cust_number,posting_date ,document_type,cust_payment_terms,clear_date,invoice_id,buisness_year, due_in_date, total_open_amount) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			
				PreparedStatement st = conn.prepareStatement(sql_statement);
				st.setString(1, BusinessCode);
				st.setString(2, docId);
				st.setString(3, invoiceCurrency);
				st.setString(4,baseLinecreatedate);
			
				st.setString(5, customerNumber);
				st.setString(6, postingDate);
				st.setString(7, doctype);
				st.setString(8, custPayTerms);
				st.setString(9, clearDate);
				//st.setString(10, doccreatedate);
				//st.setString(10, postingId);
				st.setString(10, invoiceNumber);
				st.setString(11, businessyear);
				st.setString(12, duedate);
				st.setString(13, totalopenamt);
				
				
				
				st.executeUpdate();
//				//conn.commit();
			st.close();
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
