package hrc.com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;


@WebServlet("/InvoiceCrude")
public class InvoiceCrude extends HttpServlet {
		private static final long serialVersionUID = 1L;
		private static Connection conn = null;
		private static PreparedStatement stmt = null;
	       
	    public InvoiceCrude() {
	        super();
	        
	    }
	    
	    
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
			
			
			

		    int page = Integer.parseInt(request.getParameter("page"));
			int records_per_page = 10;
			HashMap<Object,Object> Response= new HashMap<Object,Object>();
			ArrayList<InvoiceModel> data = new ArrayList<InvoiceModel>();
			
			try {
				conn = dbconnection.dbconnector();
				stmt = conn.prepareStatement(
						"SELECT * FROM mytable LIMIT " +(page-1)*records_per_page+","+records_per_page
						);
		
				ResultSet result = stmt.executeQuery();		
				while(result.next()) {
					InvoiceModel pojo = new InvoiceModel();
//					pojo.setCust_number(result.getString(2));
//					pojo.setName_customer(result.getString(3));
//					pojo.setDoc_id(result.getLong(6));
//					pojo.setDue_in_date(result.getString(9));
//					pojo.setTotal_open_amount(result.getDouble(14));
//					pojo.setInvoice_id(result.getLong(17));

					pojo.setSl_no(result.getString(1));
					pojo.setBusiness_code(result.getString(2));
					pojo.setCust_number(result.getString(3));
					//pojo.setName_customer(result.getString(4));
					pojo.setClear_date(result.getString(5));
					pojo.setBusiness_year(result.getString(6));
					pojo.setDoc_id(result.getLong(7));
					pojo.setPosting_date(result.getString(8));
					pojo.setDocument_create_date(result.getString(9));
					pojo.setDue_in_date(result.getString(11));
					pojo.setInvoice_currency(result.getString(12));
					pojo.setDocument_type(result.getString(13));
					pojo.setPosting_id(result.getInt(14));
					//pojo.setArea_business(result.getString(15));
					pojo.setTotal_open_amount(result.getDouble(16));
					pojo.setBaseline_create_date(result.getString(17));
					pojo.setCust_payment_terms(result.getString(18));
					pojo.setInvoice_id(result.getLong(19));
					pojo.setIsOpen(result.getInt(20));
					
					
					data.add(pojo);
				}
				
				Gson gson = new Gson();
				String resData = gson.toJson(data);
				PrintWriter out = response.getWriter();
				response.setContentType("application/json");
				response.setCharacterEncoding("UTF-8");
				Response.put("resData",data);
				out.print(resData);
				out.flush();
				stmt=conn.prepareStatement("select count(*) count from mytable");
				ResultSet rs=stmt.executeQuery();
				while(rs.next()) {
					String count=rs.getString("count");
					Response.put("count", count);
					
				}
				
				rs.close();
				result.close();
				stmt.close();
				
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
			doGet(request, response);
		}

		
		
}
