import React from 'react';
import axios from 'axios';
import { makeStyles } from '@material-ui/core';
import { Dialog, IconButton, Button, Input } from '@material-ui/core';
import MuiDialogTitle from '@material-ui/core/DialogTitle';
import MuiDialogContent from '@material-ui/core/DialogContent';
import MuiDialogActions from '@material-ui/core/DialogActions';
import { CloseIcon } from '../assets';

const useStyles = makeStyles((theme) => ({
    dialogPaper: {
        minHeight: '60vh', 
        maxHeight: '60vh',
        minWidth: '30vw',
        maxWidth: '30vw',
        background: '#000000',
    },
    WindowHeader: {
        background: '#2A3E4C',
        borderRadius: '10px 10px 0px 0px',
        position: 'static',
    },
    Title: {
        color: '#FFFFFF',   
        font: 'Ubuntu',
        fontWeight: 'normal',
    },
    TopRightMenu: {
        position: 'fixed',
        top: '160px',
        right: '570px',
    },
    Body: {
        fontSize: '15px',
        color: '#97A1A9',
        background: '#2A3E4C',
        paddingBlock: '40px',
    },
    InputBox: {
        color: '#383c3e',
        width: '240px',
        border: '1px solid #356680',
        background: '#FFFFFF',
        borderRadius: 5,
        paddingLeft: '10px',
        paddingRight: '10px'
    },
    ErrorInputBox: {
        color: '#FFFFFF',
        width: '240px',
        border: '1px solid #FF5B5B',
        background: '#283A46',
        borderRadius: 10,
        paddingLeft: '10px',
        paddingRight: '10px'
    },
    CancelButton: {
        color: '#FFF',
        textTransform: 'none',
        border: '1px solid #14AFF1',
        borderRadius: 1,
        height: '30px',
       
    },
  
    SaveButton: {
        color: '#FFF',
        textTransform: 'none',
        border: '1px solid #14AFF1',
        borderRadius: 1,
        height: '30px',
    },
    Column1: {
        width: '30vw',
        height: '30vh',
        paddingLeft: '40px'
    },
}))

const EditMenu = ({
    invoiceCurrency, custpayterm,
    newinvoiceCurrency, setNewinvoiceCurrency,
    newcustpayterm, setNewcustpayterm,
    setSaveButtonClicked,
    isErrorNewinvoiceCurrency
}) => {
    const classes = useStyles();

    const handleinvoiceCurrency = (event) => {
        setSaveButtonClicked(false);
        setNewinvoiceCurrency(event.target.value);
    }

    const handlecustpayterm = (event) => {
        setSaveButtonClicked(false);
        setNewcustpayterm(event.target.value);
    }

    return (
        <div style={{ display: 'flex' }}>
           
            <div classname={classes.Column1}>
                <div style={{ paddingBottom: '30px' }}>
                    <Input
                        className={isErrorNewinvoiceCurrency ? classes.ErrorInputBox : classes.InputBox}
                        disableUnderline={true}
                        value={newinvoiceCurrency}
                        placeholder="invoice Currency"
                        onChange={(event) => handleinvoiceCurrency(event)}
                    >
                    </Input>
                </div>
            </div>
                <div classname={classes.Column1}>
                    <div style={{ paddingBottom: '30px' }}>
                        <Input
                            className={classes.InputBox}
                            style={{ height: '35px' }}
                            disableUnderline={true}
                            value={newcustpayterm}
                            placeholder="customer payent terms"
                            onChange={(event) => handlecustpayterm(event)}
                        >
                        </Input>
                    </div>
                </div>
           
        </div>
    )
}

const EditInvoicePage = ({ 
    open, setOpen,
    selectedInvoiceDetails,selected,
    setDataPageCount, setData
}) => {
    const classes = useStyles();
    const [ maxWidth ] = React.useState('lg');
    const [ fullWidth ] = React.useState(false);
    const invoicenum=selected[0]

    const invoiceNumber = selectedInvoiceDetails.length === 0 ? '' : selectedInvoiceDetails[0]['doc_id']
    const invoiceCurrency = selectedInvoiceDetails.length === 0 ? '' : selectedInvoiceDetails[0]['total_open_amount']
    const custpayterm = selectedInvoiceDetails.length === 0 ? '' : selectedInvoiceDetails[0]['cust_payment_term'];

    const [ newinvoiceCurrency, setNewinvoiceCurrency ] = React.useState(invoiceCurrency);
    const [ newcustpayterm, setNewcustpayterm ] = React.useState(custpayterm);
    const [ saveButtonClicked, setSaveButtonClicked ] = React.useState(false);

    const isErrorNewinvoiceCurrency = (newinvoiceCurrency === '' && saveButtonClicked);

    const handleSave = () => {
        if(newinvoiceCurrency !== '') {
            axios.post('http://localhost:8080/highradiu/EditSalesOrder', 
            {
                invoicenum, 
                newinvoiceCurrency,
                newcustpayterm
            })
            .then((response) => {
                console.log(response);
                handleClose();
                // setData([])
                // setDataPageCount(0);
            })
            .catch((error) => {
                console.log(error);
            })
        }
        setSaveButtonClicked(true);
    }

    const handleReset = () => {
        setNewinvoiceCurrency(invoiceCurrency);
        setNewcustpayterm(custpayterm);
    }

    const handleClose = () => {
        setOpen(false);
    }

    return (
        <Dialog onClose={handleClose} open={open} maxWidth={maxWidth} fullWidth={fullWidth} classes={{ paper: classes.dialogPaper }}>
            <MuiDialogTitle className={classes.WindowHeader}>
                <div style={{ display: 'flex' }}>
                    <div className={classes.Title}>
                        Edit 
                    </div>
                    <div className={classes.TopRightMenu}>
                        <IconButton onClick={handleClose}>
                            <CloseIcon/>
                        </IconButton>
                    </div>
                </div>
            </MuiDialogTitle>
            <MuiDialogContent className={classes.Body}>
                <EditMenu
                    invoiceCurrency={invoiceCurrency} custpayterm={custpayterm}
                    newinvoiceCurrency={newinvoiceCurrency} setNewinvoiceCurrency={setNewinvoiceCurrency}
                    newcustpayterm={newcustpayterm} setNewcustpayterm={setNewcustpayterm}
                    saveButtonClicked={saveButtonClicked} setSaveButtonClicked={setSaveButtonClicked}
                    isErrorNewinvoiceCurrency={isErrorNewinvoiceCurrency}
                />
            </MuiDialogContent>
            <MuiDialogActions style={{ background: '#2A3E4C', borderRadius: '0px 0px 10px 10px' }}>
                <div style={{ paddingRight: '20px', paddingBottom: '10px' }}>
                    <Button 
                        autofocus 
                        className={classes.SaveButton}
                        onClick={handleSave}>Edit</Button>
                </div>
                <div style={{ position: 'fixed', left: '585px', paddingBottom: '10px' }}>
                    <Button 
                        autofocus 
                        className={classes.CancelButton} 
                        onClick={handleClose}
                    >
                        Cancel
                    </Button>
                </div>
               
            </MuiDialogActions>
        </Dialog>
    );
}

export default EditInvoicePage;